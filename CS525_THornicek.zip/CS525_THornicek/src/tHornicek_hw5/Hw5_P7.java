package tHornicek_hw5;

import java.util.*;

public class Hw5_P7<K> {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long startTime, endTime, elapsedTime;

		
		// Use this to set the array size
		int numberOfKeys = 10000;
		//Store random generated numbers in unsorted array 
		int[] unsortArray10k =  generateRandom(numberOfKeys);
		//printArray(unsortArray10k);
		// Measure the time for n= 10 000
		startTime = System.currentTimeMillis();
		insertionSort(unsortArray10k);
		endTime = System.currentTimeMillis();	
	 	elapsedTime = endTime - startTime;
	 	System.out.println("Runtime for insertion sort 10K: "+ elapsedTime +"ms");
	 	
		// Array for 20K entries for insertion sort
		numberOfKeys = 20000;
		// Store random generated numbers in unsorted array 
		int[] unsortArray20k =  generateRandom(numberOfKeys);
		//Measure the time for n= 20 000
		startTime = System.currentTimeMillis();
		insertionSort(unsortArray20k);
		endTime = System.currentTimeMillis();	
	 	elapsedTime = endTime - startTime;
	 	System.out.println("Runtime for insertion sort 20K: "+ elapsedTime +"ms");
	 	
		// Array for 30K entries for insertion sort
		numberOfKeys = 30000;
		// Store random generated numbers in unsorted array 
		int[] unsortArray30k =  generateRandom(numberOfKeys);
		//Measure the time for n= 30 000
		startTime = System.currentTimeMillis();
		insertionSort(unsortArray30k);
		endTime = System.currentTimeMillis();	
	 	elapsedTime = endTime - startTime;
	 	System.out.println("Runtime for insertion sort 30K: "+ elapsedTime +"ms");
	 	
		// Array for 40K entries for insertion sort
		numberOfKeys = 40000;
		// Store random generated numbers in unsorted array 
		int[] unsortArray40k =  generateRandom(numberOfKeys);
		//Measure the time for n= 40 000
		startTime = System.currentTimeMillis();
		insertionSort(unsortArray40k);
		endTime = System.currentTimeMillis();	
	 	elapsedTime = endTime - startTime;
	 	System.out.println("Runtime for insertion sort 40K: "+ elapsedTime +"ms");
	 	
		// Array for 50K entries for insertion sort
		numberOfKeys = 50000;
		// Store random generated numbers in unsorted array 
		int[] unsortArray50k =  generateRandom(numberOfKeys);
		//Measure the time for n= 50 000
		startTime = System.currentTimeMillis();
		insertionSort(unsortArray50k);
		endTime = System.currentTimeMillis();	
	 	elapsedTime = endTime - startTime;
	 	System.out.println("Runtime for insertion sort 50K: "+ elapsedTime +"ms");
	 	
	 	
		// Array for 60K entries for insertion sort
		numberOfKeys = 60000;
		// Store random generated numbers in unsorted array 
		int[] unsortArray60k =  generateRandom(numberOfKeys);
		//Measure the time for n= 60 000
		startTime = System.currentTimeMillis();
		insertionSort(unsortArray60k);
		endTime = System.currentTimeMillis();	
	 	elapsedTime = endTime - startTime;
	 	System.out.println("Runtime for insertion sort 60K: "+ elapsedTime +"ms");
	 	
	 	
		// Array for 70K entries for insertion sort
		numberOfKeys = 70000;
		// Store random generated numbers in unsorted array 
		int[] unsortArray70k =  generateRandom(numberOfKeys);
		//Measure the time for n= 70 000
		startTime = System.currentTimeMillis();
		insertionSort(unsortArray70k);
		endTime = System.currentTimeMillis();	
	 	elapsedTime = endTime - startTime;
	 	System.out.println("Runtime for insertion sort 70K: "+ elapsedTime +"ms");
	 	
		// Array for 80K entries for insertion sort
		numberOfKeys = 80000;
		// Store random generated numbers in unsorted array 
		int[] unsortArray80k =  generateRandom(numberOfKeys);
		//Measure the time for n= 80 000
		startTime = System.currentTimeMillis();
		insertionSort(unsortArray80k);
		endTime = System.currentTimeMillis();	
	 	elapsedTime = endTime - startTime;
	 	System.out.println("Runtime for insertion sort 80K: "+ elapsedTime +"ms");
	 	
		// Array for 90K entries for insertion sort
		numberOfKeys = 90000;
		// Store random generated numbers in unsorted array 
		int[] unsortArray90k =  generateRandom(numberOfKeys);
		//Measure the time for n= 90 000
		startTime = System.currentTimeMillis();
		insertionSort(unsortArray90k);
		endTime = System.currentTimeMillis();	
	 	elapsedTime = endTime - startTime;
	 	System.out.println("Runtime for insertion sort 90K: "+ elapsedTime +"ms");
	 	
		// Array for 100K entries for insertion sort
		numberOfKeys = 100000;
		// Store random generated numbers in unsorted array 
		int[] unsortArray100k =  generateRandom(numberOfKeys);
		//Measure the time for n= 100 000
		startTime = System.currentTimeMillis();
		insertionSort(unsortArray100k);
		endTime = System.currentTimeMillis();	
	 	elapsedTime = endTime - startTime;
	 	System.out.println("Runtime for insertion sort 100K: "+ elapsedTime +"ms");
	 	
	 	// Merge Sort
	 	
		// Array for 10K entries for merge sort
		numberOfKeys = 10000;
		// Store random generated numbers in unsorted array 
		int[] mergeUnsortArray10k =  generateRandom(numberOfKeys);
		//Measure the time for n= 10 000
		Comparator<Integer> comp = new DefaultComparator<Integer>();
		startTime = System.currentTimeMillis();
		Hw5_P7.mergeSort(mergeUnsortArray10k, comp);
		endTime = System.currentTimeMillis();	
	 	elapsedTime = endTime - startTime;
	 	System.out.println("Runtime for merge sort 10K: "+ elapsedTime +"ms");
	 	
		
		
	}
	
	// Insertion-sort copied from the book
	public static void insertionSort(int[]data) {
		int n = data.length;
		for (int k=1; k<n; k++) {
			int cur = data[k];
			int j = k;
			while(j>0 && data[j-1]>cur) {
				data[j] = data[j-1];
				j--;
			}
			data[j] = cur;
		}
	}
	// Quick sort copied from the book
	private static <K> void quickSortInPlace(K[]S, Comparator<K> comp, int a, int b) {
		if(a >= b)return;
		int left = a;
		int right = b-1;
		K pivot = S[b];
		K temp;
		while(left <= right) {
			// Scan until reaching value equal or larger than pivot (or right marker)
			while (left <= right && comp.compare(S[left], pivot) < 0) left++;
			// Scan until reaching value equal or smaller than pivot (or left marker)
			while (left <= right && comp.compare(S[right], pivot) > 0) right--;
			if (left <= right) {
				temp = S[left]; S[left] = S[right]; S[right] = temp;
				left++; right--;
			}
		}
		// put pivot into its final place (currently marked by left index)
		temp = S[left]; S[left] = S[b]; S[b] = temp;
		// make recursive calls
		quickSortInPlace(S, comp, a, left - 1);
		quickSortInPlace(S, comp, left + 1, b);
	}
	
	
	// Merge sort copied from the book
	public static <K> void mergeSort(K[]S, Comparator<K>comp) {
		int n = S.length;
		if(n<2) return;
		// Divide
		int mid = n/2;
		K[] S1 = Arrays.copyOfRange(S, 0, mid);
		K[] S2 = Arrays.copyOfRange(S, mid, n);
		// Conquer with recursion
		mergeSort(S1, comp);
		mergeSort(S2, comp);
		// Merge the results
		merge(S1, S2, S, comp);
		
	}
	
	// Helper function merge copied from the book
	public static <K> void merge(K[]S1, K[]S2, K[]S, Comparator<K>comp) {
		int i = 0, j = 0;
		while(i + j < S.length) {
			if(j == S2.length || (i < S1.length && comp.compare(S1[i], S2[j])< 0))
				S[i+j] = S1[i++];
			else
				S[i+j] = S2[j++];
				
		}
	}
	
	// Helper function to generate distinct random numbers
	public static int[] generateRandom(int count) {
		//Initialize new random array
		int[] randomArr = new int[count];
		Random r = new Random();
		for (int i = 0; i < randomArr.length; i++) {
			randomArr[i] = r.nextInt(1000000)+ 1;
		}
		return randomArr;
	}
	// Helper function to print array for testing
    static void printArray(int arr[])
    {
        int n = arr.length;
        for (int i = 0; i < n; ++i)
            System.out.print(arr[i] + " ");
 
        System.out.println();
    }
}
